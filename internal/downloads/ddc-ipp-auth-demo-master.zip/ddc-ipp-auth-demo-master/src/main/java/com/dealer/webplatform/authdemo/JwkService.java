package com.dealer.webplatform.authdemo;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.ResponseBody;
import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwk.JsonWebKeySet;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jwt.consumer.JwtConsumer;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;
import org.jose4j.keys.resolvers.JwksVerificationKeyResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class JwkService {

	private static final Logger log = LoggerFactory.getLogger(JwkService.class);

	private final String url;
	private final OkHttpClient client;
	private JwtConsumer consumer = null;

	public JwkService(@Value("${dealer.com.jwks.url}") String url) {
		this.url = url;
		this.client = new OkHttpClient();
	}

	@Scheduled(fixedRate = 60 * 1000)
	private void updateKeys() {
		try {
			ResponseBody body = client.newCall(new Request.Builder().url(url).build()).execute().body();
			consumer = createConsumer(new JsonWebKeySet(Objects.requireNonNull(body).string()));
		} catch (Throwable t) {
			log.error("Error updating JWKs from CDN!", t);
		}
	}

	private JwtConsumer createConsumer(JsonWebKeySet keySet) {
		return new JwtConsumerBuilder()
			.setAllowedClockSkewInSeconds(30)
			.setRequireSubject()
			.setExpectedIssuer("Dealer.com")
			.setExpectedAudience("IPP")
			.setVerificationKeyResolver(new JwksVerificationKeyResolver(keySet.getJsonWebKeys()))
			.setJwsAlgorithmConstraints(AlgorithmConstraints.ConstraintType.WHITELIST, AlgorithmIdentifiers.RSA_USING_SHA256)
			.build();
	}


	public JwtConsumer getConsumer() {
		if(consumer == null) {
			throw new IllegalStateException("JWKs not initialized yet!");
		}

		return consumer;
	}
}
