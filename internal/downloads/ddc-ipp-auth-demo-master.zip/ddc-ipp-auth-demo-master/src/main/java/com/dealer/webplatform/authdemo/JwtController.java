package com.dealer.webplatform.authdemo;

import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.MalformedClaimException;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/jwt")
public class JwtController {

	private final JwkService jwkService;

	public JwtController(JwkService jwkService) {
		this.jwkService = jwkService;
	}

	@GetMapping("/validate/{jwt}")
	public String validate(@PathVariable("jwt") String jwt) throws InvalidJwtException, MalformedClaimException {
		JwtClaims claims = jwkService.getConsumer().processToClaims(jwt);
		return String.format("JWT validated successfully!  Subject: %s, VINs: %s", claims.getSubject(), claims.getClaimValue("VINs"));
	}
}
